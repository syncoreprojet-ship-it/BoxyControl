/** Vue globale reservee aux roles de supervision avec les deux droits historiques. */
function BXCT_ENC_PERMISSIONS_read_(ctx) {
  if(!['ADMIN_CONTROL','SUPERVISEUR'].includes(ctx.agent.role)||!['CONSULTER_PAIEMENTS','CONSULTER_FINANCES_ACADEMIE'].every(p=>ctx.rights.includes(p))||ctx.settings.PAIEMENTS_ACTIFS!=='OUI'||ctx.settings.ACADEMIE_FINANCES_LECTURE_ACTIVE!=='OUI'||ctx.settings.ACADEMIE_DEVIS_OFFICIELS_VALIDES!=='OUI')throw new Error('AUTORISATION_REFUSEE');
}
